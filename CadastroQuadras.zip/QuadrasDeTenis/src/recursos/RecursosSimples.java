package recursos;

public class RecursosSimples {
	RecursosSimples(){
		
	}
	
	/*void menu(int opcao) {;
	int i=1;
		while(i<=opcao){
			if(opcao==i) {
				mostrarMensagem();
			}else if(opcao==i+1) {	
				mostrarMensagem();
			}else if(opcao==i+2) {
				mostrarMensagem();
			}else if(opcao==i+3) {
				mostrarMensagem();
			}else {
				mostrarMensagem();
			}
		}
	}
	
	void mostrarMensagem() {
		String msg="";
		System.out.println(msg);
	}*/
}
